const API_URL = "https://openlibrary.org/search.json";

export async function getBooks(query = "popular books") {
  try {
    const response = await fetch(
      `${API_URL}?q=${encodeURIComponent(query)}&limit=12`
    );

    if (!response.ok) {
      throw new Error("Gagal mengambil data buku");
    }

    const data = await response.json();

    return data.docs || [];
  } catch (error) {
    console.error("Error:", error);
    return [];
  }
}