const FAVORITE_KEY = "booktrack_favorites";

// Mengambil semua buku favorit
export function getFavorites() {
  const favorites = localStorage.getItem(FAVORITE_KEY);

  if (!favorites) {
    return [];
  }

  try {
    return JSON.parse(favorites);
  } catch (error) {
    console.error("Gagal membaca data favorit:", error);
    return [];
  }
}

// Menyimpan buku favorit
export function saveFavorites(favorites) {
  localStorage.setItem(
    FAVORITE_KEY,
    JSON.stringify(favorites)
  );
}

// Mengecek apakah buku sudah menjadi favorit
export function isFavorite(bookKey) {
  const favorites = getFavorites();

  return favorites.some(
    (book) => book.key === bookKey
  );
}

// Menambah atau menghapus favorit
export function toggleFavorite(book) {
  const favorites = getFavorites();

  const alreadyFavorite = favorites.some(
    (item) => item.key === book.key
  );

  let updatedFavorites;

  if (alreadyFavorite) {
    updatedFavorites = favorites.filter(
      (item) => item.key !== book.key
    );
  } else {
    updatedFavorites = [
      ...favorites,
      book
    ];
  }

  saveFavorites(updatedFavorites);

  return updatedFavorites;
}