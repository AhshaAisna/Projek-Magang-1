import { Search, X, ArrowRight } from "lucide-react";

function SearchBar({ value, onChange, onSubmit }) {
  const handleClear = () => {
    onChange("");
  };

  return (
    <form
      onSubmit={onSubmit}
      role="search"
      className="group relative flex items-center w-full bg-white/90 dark:bg-stone-900/80 border border-stone-300/80 dark:border-stone-800 rounded-full pl-4 pr-1.5 py-1.5 shadow-[0_2px_8px_rgba(0,0,0,0.04)] dark:shadow-[0_4px_16px_rgba(0,0,0,0.3)] focus-within:border-stone-800 dark:focus-within:border-stone-500 focus-within:ring-2 focus-within:ring-stone-900/10 dark:focus-within:ring-stone-100/10 focus-within:bg-white dark:focus-within:bg-stone-900 transition-all duration-200"
    >
      {/* Search Icon */}
      <Search
        size={18}
        className="text-stone-400 dark:text-stone-500 group-focus-within:text-stone-800 dark:group-focus-within:text-stone-200 transition-colors shrink-0"
      />

      {/* Input Field */}
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Cari judul, penulis, atau kata kunci..."
        className="w-full bg-transparent px-3 py-1.5 text-sm text-stone-900 dark:text-stone-100 placeholder:text-stone-400 dark:placeholder:text-stone-500 focus:outline-none"
      />

      {/* Clear Button */}
      {value && (
        <button
          type="button"
          onClick={handleClear}
          aria-label="Bersihkan pencarian"
          className="p-1 mr-1 text-stone-400 dark:text-stone-500 hover:text-stone-700 dark:hover:text-stone-300 rounded-full hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors cursor-pointer shrink-0"
        >
          <X size={15} />
        </button>
      )}

      {/* Submit Button */}
      <button
        type="submit"
        aria-label="Submit search"
        className="inline-flex items-center justify-center h-8 w-8 sm:w-auto sm:px-3.5 sm:gap-1.5 rounded-full bg-stone-900 dark:bg-stone-100 hover:bg-stone-800 dark:hover:bg-stone-200 text-stone-50 dark:text-stone-900 text-xs font-medium transition-colors shrink-0 cursor-pointer shadow-xs"
      >
        <span className="hidden sm:inline">Cari</span>
        <ArrowRight size={13} strokeWidth={2.2} />
      </button>
    </form>
  );
}

export default SearchBar;