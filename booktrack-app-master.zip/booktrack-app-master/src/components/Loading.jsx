function Loading({ type = "skeleton" }) {
  // Opsi 1: Skeleton Card Grid (Sangat natural, anti-AI)
  if (type === "skeleton") {
    return (
      <div 
        aria-busy="true"
        aria-label="Memuat katalog buku"
        className="w-full grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10 animate-pulse"
      >
        {Array.from({ length: 8 }).map((_, index) => (
          <div key={index} className="flex flex-col">
            {/* Sampul Buku */}
            <div className="w-full aspect-[2/3] bg-stone-200/70 rounded-r-md rounded-l-xs shadow-xs" />
            
            {/* Siluet Judul */}
            <div className="mt-4 space-y-2">
              <div className="h-4 bg-stone-200/90 rounded-xs w-4/5" />
              <div className="h-4 bg-stone-200/60 rounded-xs w-2/3" />
            </div>

            {/* Penulis & Tahun */}
            <div className="mt-3 flex items-center justify-between">
              <div className="h-3 bg-stone-200/60 rounded-xs w-1/3" />
              <div className="h-3 bg-stone-200/40 rounded-xs w-8" />
            </div>
          </div>
        ))}
      </div>
    );
  }
  
  return (
    <div 
      aria-live="polite" 
      className="flex flex-col items-center justify-center py-20 text-stone-500"
    >
      <div className="w-6 h-6 rounded-full border border-stone-300 border-t-stone-800 animate-spin" />
      <span className="mt-4 text-xs tracking-widest uppercase font-mono text-stone-400">
        Fetching records...
      </span>
    </div>
  );
}

export default Loading;