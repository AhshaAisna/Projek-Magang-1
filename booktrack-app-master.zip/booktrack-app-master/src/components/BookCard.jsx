import { useState } from "react";
import { Link } from "react-router-dom";
import { Bookmark } from "lucide-react";

import { getFavorites, toggleFavorite } from "../utils/localStorage";

function BookCard({ book, onFavoriteChange }) {
  const [isFavorite, setIsFavorite] = useState(() => {
    const list = getFavorites() || [];
    return list.some((item) => (item.key || item.id) === (book.key || book.id));
  });

  const handleFavorite = (e) => {
    e.preventDefault();
    e.stopPropagation();

    toggleFavorite(book);
    setIsFavorite((prev) => !prev);
    
    if (onFavoriteChange) {
      onFavoriteChange();
    }
  };

  const cover = book.cover_i
    ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg`
    : null;

  const author = book.author_name?.[0] || "Penulis Tidak Diketahui";
  const year = book.first_publish_year || "—";
  const bookKey = book.key ? encodeURIComponent(book.key.replace("/works/", "")) : book.id;

  return (
    <div className="group relative flex flex-col">
      {/* Container Sampul Buku */}
      <div className="relative aspect-[2/3] w-full rounded-r-md rounded-l-xs overflow-hidden bg-stone-100 dark:bg-stone-900 border border-transparent dark:border-stone-800/80 shadow-[2px_4px_12px_rgba(0,0,0,0.08)] dark:shadow-[0_4px_16px_rgba(0,0,0,0.4)] transition-all duration-300 group-hover:-translate-y-1.5 group-hover:shadow-[4px_10px_20px_rgba(0,0,0,0.14)] dark:group-hover:shadow-[0_8px_24px_rgba(0,0,0,0.6)]">
        
        {/* Subtle Book Spine Crease Effect */}
        <div className="absolute inset-y-0 left-0 w-2.5 bg-gradient-to-r from-black/25 via-white/10 to-transparent pointer-events-none z-10" />

        {cover ? (
          <img
            src={cover}
            alt={`Sampul buku ${book.title}`}
            loading="lazy"
            className="h-full w-full object-cover object-center"
          />
        ) : (
          <div className="flex h-full w-full flex-col justify-between p-4 bg-stone-100 dark:bg-[#1c1a17] border border-stone-200/80 dark:border-stone-800">
            <span className="font-mono text-[10px] tracking-widest uppercase text-stone-400 dark:text-stone-500">
              No Cover
            </span>
            <p className="font-serif text-sm font-medium text-stone-700 dark:text-stone-300 line-clamp-3 leading-snug">
              {book.title}
            </p>
            <span className="text-[11px] text-stone-400 dark:text-stone-500 truncate">{author}</span>
          </div>
        )}

        {/* Action Button: Bookmark */}
        <button
          type="button"
          onClick={handleFavorite}
          aria-label={isFavorite ? "Hapus dari rak simpanan" : "Simpan ke rak bacaan"}
          className={`absolute top-2.5 right-2.5 z-20 h-8 w-8 rounded-full flex items-center justify-center backdrop-blur-md transition-all duration-200 cursor-pointer ${
            isFavorite
              ? "bg-stone-900 dark:bg-stone-100 text-stone-50 dark:text-stone-900 shadow-sm"
              : "bg-white/85 dark:bg-stone-900/85 text-stone-600 dark:text-stone-300 hover:bg-white dark:hover:bg-stone-800 hover:text-stone-900 dark:hover:text-stone-100 opacity-90 sm:opacity-0 group-hover:opacity-100 shadow-xs border border-transparent dark:border-stone-700/60"
          }`}
        >
          <Bookmark size={14} className={isFavorite ? "fill-current" : ""} />
        </button>

        {/* Overlay Link untuk Navigasi Cepat via Gambar */}
        <Link
          to={`/book/${bookKey}`}
          state={{ book }}
          aria-label={`Lihat detail ${book.title}`}
          className="absolute inset-0 z-0"
        />
      </div>

      {/* Metadata / Keterangan Buku */}
      <div className="mt-3.5 flex flex-col flex-1">
        <div className="flex items-baseline justify-between gap-2 text-[11px] text-stone-400 dark:text-stone-500 font-mono mb-1">
          <span className="truncate max-w-[70%]">{author}</span>
          <span className="shrink-0">{year}</span>
        </div>

        <Link
          to={`/book/${bookKey}`}
          state={{ book }}
          className="group/title focus:outline-none"
        >
          <h3 className="font-serif text-stone-900 dark:text-stone-100 text-sm font-medium leading-snug line-clamp-2 group-hover/title:text-stone-600 dark:group-hover/title:text-stone-300 transition-colors">
            {book.title}
          </h3>
        </Link>
      </div>
    </div>
  );
}

export default BookCard;