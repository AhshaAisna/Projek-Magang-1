import { Link, useLocation } from "react-router-dom";
import { Bookmark, Compass, Sun, Moon } from "lucide-react";
import { useState, useEffect } from "react";
import { getFavorites } from "../utils/localStorage";
import { useTheme } from "../context/ThemeContext";

function Navbar() {
  const location = useLocation();
  const [favoriteCount, setFavoriteCount] = useState(0);
  const { isDark, toggleTheme } = useTheme();

  // jumlah buku yang tersimpan
  useEffect(() => {
    const updateCount = () => {
      const items = getFavorites?.() || [];
      setFavoriteCount(items.length);
    };

    updateCount();
    window.addEventListener("storage", updateCount);
    return () => window.removeEventListener("storage", updateCount);
  }, [location.pathname]);

  const navItems = [
    {
      label: "Katalog",
      path: "/",
      icon: Compass,
    },
    {
      label: "Favorit",
      path: "/favorites",
      icon: Bookmark,
      badge: favoriteCount > 0 ? favoriteCount : null,
    },
  ];

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-[#FDFBF7]/90 dark:bg-[#141210]/90 border-b border-stone-200/80 dark:border-stone-800/80 transition-colors duration-200">
      <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
        
        {/* Brand / Logo */}
        <Link 
          to="/" 
          className="group flex items-center gap-2.5 focus:outline-none"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-stone-900 dark:bg-stone-100 group-hover:scale-125 transition-transform duration-200" />
          <span className="font-serif text-lg tracking-tight font-medium text-stone-900 dark:text-stone-100">
            BookTrack
          </span>
        </Link>

        {/* Right Controls: Nav Links + Theme Switcher */}
        <div className="flex items-center gap-3">
          {/* Navigation Controls Wrapper */}
          <nav className="flex items-center p-1 bg-stone-200/70 dark:bg-stone-900/90 rounded-full border border-stone-300/60 dark:border-stone-800 shadow-xs">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;

              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`relative inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium transition-all duration-200 focus:outline-none ${
                    isActive
                      ? "bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-50 shadow-xs dark:shadow-stone-950/40"
                      : "text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100"
                  }`}
                >
                  <Icon
                    size={14}
                    strokeWidth={isActive ? 2 : 1.75}
                    className={
                      isActive
                        ? "text-stone-900 dark:text-stone-50"
                        : "text-stone-500 dark:text-stone-400"
                    }
                  />
                  <span>{item.label}</span>

                  {/* Badge Angka Simpanan */}
                  {item.badge !== null && (
                    <span
                      className={`ml-0.5 px-1.5 py-0.2 text-[10px] font-mono rounded-full transition-colors ${
                        isActive
                          ? "bg-stone-100 dark:bg-stone-700/80 text-stone-800 dark:text-stone-200"
                          : "bg-stone-300/80 dark:bg-stone-800 text-stone-700 dark:text-stone-400"
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Theme Toggle Button */}
          <button
            type="button"
            onClick={toggleTheme}
            aria-label="Ganti tema tampilan"
            className="h-8 w-8 rounded-full border border-stone-200/90 dark:border-stone-700/80 bg-stone-100 dark:bg-stone-800/80 text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-stone-50 hover:bg-stone-200/60 dark:hover:bg-stone-700 flex items-center justify-center transition-all cursor-pointer shadow-xs"
          >
            {isDark ? (
              <Sun size={14} strokeWidth={2} className="text-amber-400" />
            ) : (
              <Moon size={14} strokeWidth={2} className="text-stone-600" />
            )}
          </button>
        </div>

      </div>
    </header>
  );
}

export default Navbar;