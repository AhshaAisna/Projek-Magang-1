import { Link, useLocation } from "react-router-dom";
import { ArrowLeft, Bookmark } from "lucide-react";
import { useState, useEffect } from "react";
import { getFavorites, saveFavorites } from "../utils/localStorage";

function BookDetail() {
  const location = useLocation();
  const book = location.state?.book;

  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    if (book) {
      const saved = getFavorites?.() || [];
      setIsSaved(saved.some((item) => (item.key || item.id) === (book.key || book.id)));
    }
  }, [book]);

  const toggleSave = () => {
    const saved = getFavorites?.() || [];
    const id = book.key || book.id;
    let updated;
    if (isSaved) {
      updated = saved.filter((item) => (item.key || item.id) !== id);
    } else {
      updated = [...saved, book];
    }
    saveFavorites?.(updated);
    setIsSaved(!isSaved);
  };

  if (!book) {
    return (
      <main className="min-h-screen bg-[#FDFBF7] dark:bg-[#141210] text-stone-900 dark:text-stone-100 flex items-center justify-center px-6 transition-colors duration-200">
        <div className="max-w-md text-center py-16 border border-stone-200/80 dark:border-stone-800 bg-white/60 dark:bg-stone-900/60 backdrop-blur-xs rounded-2xl p-8 shadow-xs">
          <p className="font-serif text-2xl font-normal text-stone-800 dark:text-stone-200">Buku tidak ditemukan</p>
          <p className="text-stone-500 dark:text-stone-400 text-sm mt-2 leading-relaxed">
            Data buku hilang karena halaman dimuat ulang secara langsung. Silakan kembali ke katalog.
          </p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 mt-6 text-xs uppercase tracking-wider font-semibold text-stone-800 dark:text-stone-200 border-b border-stone-800 dark:border-stone-200 pb-0.5 hover:text-stone-500 dark:hover:text-stone-400 transition-colors"
          >
            <ArrowLeft size={14} />
            Kembali ke Beranda
          </Link>
        </div>
      </main>
    );
  }

  const cover = book.cover_i
    ? `https://covers.openlibrary.org/b/id/${book.cover_i}-L.jpg`
    : null;

  const authors = book.author_name?.join(", ") || "Penulis Tidak Diketahui";
  const publishYear = book.first_publish_year || "—";
  const editionsCount = book.edition_count ? `${book.edition_count} edisi tercatat` : "—";
  const languages = book.language?.slice(0, 3).join(", ") || "—";
  const subjectList = Array.isArray(book.subject) ? book.subject.slice(0, 8) : [];

  return (
    <main className="min-h-screen bg-[#FDFBF7] dark:bg-[#141210] text-stone-900 dark:text-stone-100 antialiased selection:bg-stone-200 dark:selection:bg-stone-800 transition-colors duration-200">
      <div className="max-w-4xl mx-auto px-6 py-12 md:py-16">
        
        {/* Top Navigation */}
        <div className="mb-10">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-xs uppercase tracking-wider text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 font-semibold transition-colors"
          >
            <ArrowLeft size={14} />
            Kembali ke Koleksi
          </Link>
        </div>

        {/* Main Work Layout */}
        <article className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-14 items-start">
          
          {/* Cover Column  */}
          <div className="md:col-span-5 flex flex-col items-center">
            <div className="relative group w-full max-w-[280px]">
              {cover ? (
                <div className="relative rounded-r-md rounded-l-xs overflow-hidden shadow-[4px_6px_20px_-2px_rgba(0,0,0,0.18),0_2px_6px_rgba(0,0,0,0.08)] dark:shadow-[0_8px_30px_rgba(0,0,0,0.6)] border border-transparent dark:border-stone-800/80 transition-transform duration-300 group-hover:-translate-y-1">
                  {/* Subtle Book  */}
                  <div className="absolute inset-y-0 left-0 w-3 bg-gradient-to-r from-black/25 via-white/10 to-transparent pointer-events-none z-10" />
                  <img
                    src={cover}
                    alt={`Sampul buku ${book.title}`}
                    className="w-full aspect-[2/3] object-cover bg-stone-200 dark:bg-stone-900"
                  />
                </div>
              ) : (
                <div className="w-full aspect-[2/3] bg-stone-100 dark:bg-[#1c1a17] border border-stone-300/80 dark:border-stone-800 rounded-r-md rounded-l-xs flex flex-col items-center justify-center p-6 text-center shadow-xs">
                  <span className="font-serif text-stone-400 dark:text-stone-500 italic text-sm">Cover belum tersedia</span>
                </div>
              )}
            </div>

            {/* Quick Action Button */}
            <button
              onClick={toggleSave}
              className={`mt-6 w-full max-w-[280px] inline-flex items-center justify-center gap-2 text-xs font-medium py-2.5 px-4 rounded-full border transition-all cursor-pointer shadow-xs ${
                isSaved
                  ? "bg-stone-900 dark:bg-stone-100 text-stone-50 dark:text-stone-900 border-stone-900 dark:border-stone-100 hover:bg-stone-800 dark:hover:bg-stone-200"
                  : "bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 border-stone-300 dark:border-stone-700 hover:border-stone-500 dark:hover:border-stone-500 hover:text-stone-950 dark:hover:text-stone-100"
              }`}
            >
              <Bookmark size={14} className={isSaved ? "fill-current" : ""} />
              <span>{isSaved ? "Tersimpan di Rak" : "Simpan ke Rak Bacaan"}</span>
            </button>
          </div>

          {/* Book Details Column */}
          <div className="md:col-span-7 flex flex-col">
            <header className="border-b border-stone-200 dark:border-stone-800 pb-6">
              <span className="text-[11px] font-mono tracking-widest text-stone-400 dark:text-stone-500 uppercase">
                Bibliographic Index
              </span>
              <h1 className="font-serif text-3xl sm:text-4xl font-normal text-stone-950 dark:text-stone-50 mt-2 leading-tight">
                {book.title}
              </h1>
              <p className="text-stone-600 dark:text-stone-400 text-base mt-2 font-normal">
                Karya <span className="text-stone-900 dark:text-stone-200 font-medium">{authors}</span>
              </p>
            </header>

            {/* Editorial Metadata Table */}
            <section className="py-6 border-b border-stone-200/80 dark:border-stone-800/80 text-sm">
              <h2 className="text-xs uppercase font-semibold text-stone-400 dark:text-stone-500 tracking-wider mb-4">
                Informasi Penerbitan
              </h2>
              <dl className="grid grid-cols-2 gap-y-4 gap-x-6">
                <div>
                  <dt className="text-xs text-stone-500 dark:text-stone-400">Tahun Pertama Terbit</dt>
                  <dd className="font-mono text-stone-800 dark:text-stone-200 text-sm mt-0.5">{publishYear}</dd>
                </div>
                <div>
                  <dt className="text-xs text-stone-500 dark:text-stone-400">Jumlah Edisi</dt>
                  <dd className="font-mono text-stone-800 dark:text-stone-200 text-sm mt-0.5">{editionsCount}</dd>
                </div>
                <div>
                  <dt className="text-xs text-stone-500 dark:text-stone-400">Bahasa</dt>
                  <dd className="text-stone-800 dark:text-stone-200 text-sm mt-0.5 capitalize">{languages}</dd>
                </div>
                <div>
                  <dt className="text-xs text-stone-500 dark:text-stone-400">Akses Terbuka</dt>
                  <dd className="text-stone-800 dark:text-stone-200 text-sm mt-0.5">Open Library Record</dd>
                </div>
              </dl>
            </section>

            {/* Subjects / Tags */}
            <section className="pt-6">
              <h2 className="text-xs uppercase font-semibold text-stone-400 dark:text-stone-500 tracking-wider mb-3">
                Topik Terkait
              </h2>
              {subjectList.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {subjectList.map((subj, idx) => (
                    <span
                      key={idx}
                      className="text-xs bg-stone-100 dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 text-stone-700 dark:text-stone-300 px-3 py-1 rounded-md"
                    >
                      {subj}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-stone-400 dark:text-stone-500 text-sm italic">Informasi subjek tidak terdata.</p>
              )}
            </section>
          </div>

        </article>

      </div>
    </main>
  );
}

export default BookDetail;