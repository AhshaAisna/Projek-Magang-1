import { useEffect, useState } from "react";
import { getBooks } from "../services/bookApi";
import BookCard from "../components/BookCard";
import SearchBar from "../components/SearchBar";
import Loading from "../components/Loading";

function Home() {
  const [books, setBooks] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [currentQuery, setCurrentQuery] = useState("Popular Books");

  const fetchBooks = async (query = "popular books") => {
    setLoading(true);
    const result = await getBooks(query);
    setBooks(result || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  const handleSearch = (event) => {
    event.preventDefault();
    const keyword = search.trim();

    if (keyword === "") {
      setCurrentQuery("Popular Books");
      fetchBooks();
      return;
    }

    setCurrentQuery(`Results for "${keyword}"`);
    fetchBooks(keyword);
  };

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-[#141210] text-stone-900 dark:text-stone-100 font-sans antialiased transition-colors duration-200">
      {/* ================= HERO ================= */}
      <header className="border-b border-stone-200 dark:border-stone-800/80 bg-white dark:bg-[#171513]">
        <div className="max-w-6xl mx-auto px-6 pt-16 pb-14">
          <div className="max-w-3xl">
            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-normal tracking-tight text-stone-900 dark:text-stone-50 leading-[1.15]">
              Read deeper, <br />
              <span className="italic font-light text-stone-600 dark:text-stone-400">
                remember what moved you.
              </span>
            </h1>

            <p className="mt-5 text-stone-600 dark:text-stone-400 text-base sm:text-lg leading-relaxed max-w-xl">
              Catat bacaan favorit, temukan judul baru, dan susun rak buku pribadi Anda di BookTrack.
            </p>

            <div className="mt-8">
              <SearchBar
                value={search}
                onChange={setSearch}
                onSubmit={handleSearch}
              />
            </div>
          </div>
        </div>
      </header>

      {/* ================= BOOK LIST ================= */}
      <main className="max-w-6xl mx-auto px-6 py-12">
        {/* Section Header */}
        <div className="flex items-baseline justify-between border-b border-stone-200 dark:border-stone-800 pb-4 mb-8">
          <div>
            <h2 className="font-serif text-2xl font-medium text-stone-900 dark:text-stone-100">
              {currentQuery}
            </h2>
            <p className="text-xs tracking-wider uppercase text-stone-500 dark:text-stone-400 mt-1">
              {!loading && `${books.length} items catalog`}
            </p>
          </div>
        </div>

        {/* Loading */}
        {loading && (
          <div className="py-20">
            <Loading />
          </div>
        )}

        {/* Empty State */}
        {!loading && books.length === 0 && (
          <div className="rounded-lg border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#1c1a17] p-12 text-center my-8 shadow-xs">
            <p className="font-serif text-lg text-stone-800 dark:text-stone-200">Judul tidak ditemukan</p>
            <p className="text-stone-500 dark:text-stone-400 text-sm mt-1">
              Coba gunakan judul lain, nama penulis, atau topik umum.
            </p>
          </div>
        )}

        {/* Book Grid */}
        {!loading && books.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-x-6 gap-y-10">
            {books.map((book) => (
              <BookCard key={book.key} book={book} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

export default Home;