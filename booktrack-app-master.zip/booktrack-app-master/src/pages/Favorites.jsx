import { useEffect, useState } from "react";
import { Bookmark, ArrowRight, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";

import BookCard from "../components/BookCard";
import { getFavorites } from "../utils/localStorage";

function Favorites() {
  const [favorites, setFavorites] = useState([]);

  const loadFavorites = () => {
    const savedFavorites = getFavorites();
    setFavorites(savedFavorites || []);
  };

  useEffect(() => {
    loadFavorites();
  }, []);

  const handleClearAll = () => {
    if (window.confirm("Kosongkan semua koleksi dari rak simpanan?")) {
      localStorage.removeItem("favorites");
      setFavorites([]);
    }
  };

  return (
    <main className="min-h-screen bg-[#FDFBF7] dark:bg-[#141210] text-stone-900 dark:text-stone-100 antialiased selection:bg-stone-200 dark:selection:bg-stone-800 transition-colors duration-200">
      <div className="max-w-5xl mx-auto px-6 py-14 md:py-18">
        
        {/* ================= HEADER ================= */}
        <header className="border-b border-stone-200/90 dark:border-stone-800/80 pb-7 mb-10 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-[11px] font-mono tracking-widest uppercase text-stone-400 dark:text-stone-500">
              Personal Archive
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl font-normal tracking-tight text-stone-900 dark:text-stone-100 mt-1">
              Rak Favorit
            </h1>
            <p className="text-stone-500 dark:text-stone-400 text-sm mt-1.5 font-normal max-w-md">
              Koleksi buku yang telah Anda tandai untuk dibaca nanti.
            </p>
          </div>

          {favorites.length > 0 && (
            <div className="flex items-center gap-3 sm:self-end">
              <span className="text-xs font-mono text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 px-2.5 py-1 rounded-full">
                {favorites.length} {favorites.length === 1 ? "buku" : "buku"}
              </span>

              <button
                type="button"
                onClick={handleClearAll}
                className="inline-flex items-center gap-1.5 text-xs text-stone-400 dark:text-stone-500 hover:text-red-600 dark:hover:text-red-400 transition-colors cursor-pointer py-1 px-2 rounded-md hover:bg-stone-100 dark:hover:bg-stone-900"
                title="Hapus semua"
              >
                <Trash2 size={13} />
                <span>Kosongkan rak</span>
              </button>
            </div>
          )}
        </header>

        {/* ================= EMPTY STATE ================= */}
        {favorites.length === 0 && (
          <div className="rounded-xl border border-dashed border-stone-300 dark:border-stone-800 bg-stone-50/60 dark:bg-stone-900/40 py-20 px-6 text-center max-w-md mx-auto my-8">
            <div className="w-11 h-11 rounded-full bg-stone-100 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60 flex items-center justify-center mx-auto text-stone-500 dark:text-stone-400 mb-4">
              <Bookmark size={18} strokeWidth={1.75} />
            </div>

            <h2 className="font-serif text-xl font-normal text-stone-900 dark:text-stone-100">
              Rak masih kosong
            </h2>

            <p className="text-stone-500 dark:text-stone-400 text-xs sm:text-sm mt-1.5 leading-relaxed">
              Belum ada buku yang ditandai. Jelajahi katalog dan tekan ikon bookmark untuk menyimpannya ke sini.
            </p>

            <div className="mt-6">
              <Link
                to="/"
                className="inline-flex items-center gap-2 bg-stone-900 dark:bg-stone-100 text-stone-50 dark:text-stone-900 text-xs font-medium px-4 py-2.5 rounded-full hover:bg-stone-800 dark:hover:bg-stone-200 transition-colors shadow-xs"
              >
                <span>Buka Katalog</span>
                <ArrowRight size={13} />
              </Link>
            </div>
          </div>
        )}

        {/* ================= BOOK GRID ================= */}
        {favorites.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
            {favorites.map((book) => (
              <BookCard
                key={book.key || book.id}
                book={book}
                onFavoriteChange={loadFavorites}
              />
            ))}
          </div>
        )}

      </div>
    </main>
  );
}

export default Favorites;